from flask import *
import requests
from bs4 import BeautifulSoup


    

app = Flask(__name__)

@app.route("/")
@app.route("/index")
def open():
    URL = 'https://www.jagranjosh.com/general-knowledge/list-of-famous-slogans-of-pre-and-post-independent-india-1536923044-1'
    def getdata(url):
        r = requests.get(url)
        return r.text

    htmldata = getdata(URL)
    soup = BeautifulSoup(htmldata, 'html.parser')

    table=soup.find('table')
    tr=table.findAll('tr')
    l1=[]
    for i in tr:
        for j in i.findAll('td'):
            l1.append(j.text)
    l1.pop(0)
    l1.pop(0)
    d={}
    lenth=len(l1)/2+1
    for i in range(1,int(lenth)):
        d[l1[0]]=l1[1]
        l1.pop(0)
        l1.pop(0)
    return render_template("index.html",slogans=d)



@app.route("/details")
def details():
    name=request.args.get('name')
    URL = 'https://en.wikipedia.org/wiki/'+name
    def getdata(url):
        r = requests.get(url)
        return r.text

    htmldata = getdata(URL)
    soup = BeautifulSoup(htmldata, 'html.parser')
    p=soup.findAll('p')
    td=soup.find(class_='infobox-image')
    image=td.findAll("img")
    d={}
    d[image[0].get("src")]=p[1].text+ "\n" +p[2].text + "\n" +p[3].text+ "\n" +p[4].text+ "\n" +p[5].text




    URL = 'https://www.jagranjosh.com/general-knowledge/list-of-famous-slogans-of-pre-and-post-independent-india-1536923044-1'
    def getdata(url):
        r = requests.get(url)
        return r.text

    htmldata = getdata(URL)
    soup = BeautifulSoup(htmldata, 'html.parser')

    table=soup.find('table')
    tr=table.findAll('tr')
    l1=[]
    for i in tr:
        for j in i.findAll('td'):
            l1.append(j.text)
    l1.pop(0)
    l1.pop(0)
    d1={}
    lenth=len(l1)/2+1
    for i in range(1,int(lenth)):
        d1[l1[0]]=l1[1]
        l1.pop(0)
        l1.pop(0)
    return render_template("index.html",modal="show",details=d,slogans=d1,n=name)




if __name__ == "__main__":
    app.run(debug=True)
